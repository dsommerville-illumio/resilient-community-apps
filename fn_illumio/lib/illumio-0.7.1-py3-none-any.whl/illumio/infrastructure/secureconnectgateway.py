from dataclasses import dataclass

from illumio.util import ModifiableObject


@dataclass
class SecureConnectGateway(ModifiableObject):
    pass
