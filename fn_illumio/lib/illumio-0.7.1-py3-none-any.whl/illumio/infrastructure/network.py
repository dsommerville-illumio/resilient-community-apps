from dataclasses import dataclass

from illumio.util import ModifiableObject


@dataclass
class Network(ModifiableObject):
    pass
