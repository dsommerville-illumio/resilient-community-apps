from dataclasses import dataclass

from .rule import BaseRule


@dataclass
class EnforcementBoundary(BaseRule):
    pass
